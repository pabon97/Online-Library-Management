Implementation of HTTP::Headers using XS and a custom C data structure to store the headers.
