package Foo;
use base 'DBIx::Class::Schema';
use strict;
use warnings;

__PACKAGE__->load_namespaces;

1;
