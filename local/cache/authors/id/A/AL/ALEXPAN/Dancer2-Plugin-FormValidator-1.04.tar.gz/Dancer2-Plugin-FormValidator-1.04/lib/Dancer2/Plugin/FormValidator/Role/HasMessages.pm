package Dancer2::Plugin::FormValidator::Role::HasMessages;

use strict;
use warnings;

use Moo::Role;

requires 'messages';

1;