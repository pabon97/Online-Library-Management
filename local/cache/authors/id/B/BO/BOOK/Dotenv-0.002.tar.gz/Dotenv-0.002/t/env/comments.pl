qw(
    ker_sploosh zapeth
    wham_eth thwape
)
