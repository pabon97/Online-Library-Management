qw(
  PLAIN     true
  OPTION_A  1
  OPTION_B  2
  OPTION_C  3
  OPTION_D  4
  OPTION_E  5
)
