qw(
  QUOTED    true
  OPTION_A  1
  OPTION_B  2
  OPTION_D  \n
  OPTION_E  1
  OPTION_F  2
),
OPTION_C => '',
OPTION_G => "",
OPTION_H => "\n",
